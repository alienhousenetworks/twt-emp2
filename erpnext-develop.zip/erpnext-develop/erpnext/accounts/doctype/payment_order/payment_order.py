# Copyright (c) 2018, Frappe Technologies Pvt. Ltd. and contributors
# For license information, please see license.txt


import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import nowdate

from erpnext.accounts.party import get_party_account


class PaymentOrder(Document):
	# begin: auto-generated types
	# This code is auto-generated. Do not modify anything in this block.

	from typing import TYPE_CHECKING

	if TYPE_CHECKING:
		from frappe.types import DF

		from erpnext.accounts.doctype.payment_order_reference.payment_order_reference import (
			PaymentOrderReference,
		)

		account: DF.Data | None
		amended_from: DF.Link | None
		company: DF.Link
		company_bank: DF.Link | None
		company_bank_account: DF.Link
		naming_series: DF.Literal["PMO-"]
		party: DF.Link | None
		payment_order_type: DF.Literal["", "Payment Request", "Payment Entry"]
		posting_date: DF.Date | None
		references: DF.Table[PaymentOrderReference]
	# end: auto-generated types

	def validate(self):
		self.validate_reference_type()
		self.validate_company_bank_account()
		self.validate_reference_company()

	def before_mapping(self, source_doc, table_maps):
		self.validate_reference_type(source_doc.doctype)

	def validate_reference_type(self, payment_order_type=None):
		payment_order_type = payment_order_type or self.payment_order_type
		if not payment_order_type:
			return

		for row in self.references:
			if payment_order_type == "Payment Request" and row.payment_request:
				continue
			if (
				payment_order_type == "Payment Entry"
				and row.reference_doctype == "Payment Entry"
				and not row.payment_request
			):
				continue

			frappe.throw(
				_("Row #{0}: Only {1} references are allowed in this Payment Order.").format(
					row.idx, _(payment_order_type)
				)
			)

	def validate_reference_company(self):
		if not self.payment_order_type:
			return

		ref_field = "payment_request" if self.payment_order_type == "Payment Request" else "reference_name"
		references = {d.get(ref_field) for d in self.references if d.get(ref_field)}
		if not references:
			return

		reference_company = frappe._dict(
			frappe.get_all(
				self.payment_order_type,
				filters={"name": ["in", list(references)]},
				fields=["name", "company"],
				as_list=True,
			)
		)
		for d in self.references:
			company = reference_company.get(d.get(ref_field))
			if company and company != self.company:
				frappe.throw(
					_("Row #{0}: {1} {2} belongs to Company {3}, not {4}").format(
						d.idx, _(self.payment_order_type), d.get(ref_field), company, self.company
					)
				)

	def validate_company_bank_account(self):
		if not self.company_bank_account:
			return

		bank_account = frappe.get_cached_value(
			"Bank Account",
			self.company_bank_account,
			["is_company_account", "company", "disabled", "bank", "account"],
			as_dict=True,
		)
		if not bank_account or bank_account.disabled:
			frappe.throw(_("Bank Account {0} is missing or disabled").format(self.company_bank_account))

		if not bank_account.is_company_account or bank_account.company != self.company:
			frappe.throw(
				_("Bank Account {0} must be a company account belonging to {1}").format(
					self.company_bank_account, self.company
				)
			)

		self.company_bank = bank_account.bank
		self.account = bank_account.account

	def on_submit(self):
		self.update_payment_status()

	def on_cancel(self):
		self.update_payment_status(cancel=True)

	def update_payment_status(self, cancel=False):
		status = "Payment Ordered"
		if cancel:
			status = "Initiated"

		if self.payment_order_type == "Payment Request":
			ref_field = "status"
			ref_doc_field = frappe.scrub(self.payment_order_type)
		else:
			ref_field = "payment_order_status"
			ref_doc_field = "reference_name"

		for d in self.references:
			frappe.db.set_value(self.payment_order_type, d.get(ref_doc_field), ref_field, status)


def _readable_payment_order(filters: dict) -> str | None:
	"""Authorise the parent before reading its rows.

	A child table carries no permissions of its own, so a read of it has to be authorised on the
	Payment Order the rows belong to.
	"""
	parent = filters.get("parent")
	if not parent or not frappe.db.exists("Payment Order", parent):
		return None

	ptype = "select" if frappe.only_has_select_perm("Payment Order") else "read"
	frappe.has_permission("Payment Order", ptype, doc=parent, throw=True)
	return parent


@frappe.whitelist()
@frappe.validate_and_sanitize_search_inputs
def get_mop_query(doctype: str, txt: str, searchfield: str, start: int, page_len: int, filters: dict):
	if not _readable_payment_order(filters):
		return []

	return frappe.get_all(
		"Payment Order Reference",
		filters={"parent": filters.get("parent"), "mode_of_payment": ["like", f"%{txt}%"]},
		fields=["mode_of_payment"],
		limit_start=start,
		limit_page_length=page_len,
		order_by="",  # match the original query (no ORDER BY); avoid get_all's default sort
		as_list=True,
	)


@frappe.whitelist()
@frappe.validate_and_sanitize_search_inputs
def get_supplier_query(doctype: str, txt: str, searchfield: str, start: int, page_len: int, filters: dict):
	if not _readable_payment_order(filters):
		return []

	return frappe.get_all(
		"Payment Order Reference",
		filters={
			"parent": filters.get("parent"),
			"supplier": ["like", f"%{txt}%"],
			"payment_reference": ["is", "not set"],
		},
		fields=["supplier"],
		limit_start=start,
		limit_page_length=page_len,
		order_by="",  # match the original query (no ORDER BY); avoid get_all's default sort
		as_list=True,
	)


@frappe.whitelist()
def make_payment_records(name: str, supplier: str, mode_of_payment: str | None = None):
	doc = frappe.get_doc("Payment Order", name)
	doc.check_permission()
	make_journal_entry(doc, supplier, mode_of_payment)


def make_journal_entry(doc, supplier, mode_of_payment=None):
	je = frappe.new_doc("Journal Entry")
	je.company = doc.company
	je.payment_order = doc.name
	je.posting_date = nowdate()
	mode_of_payment_type = frappe._dict(frappe.get_all("Mode of Payment", fields=["name", "type"], as_list=1))

	je.voucher_type = "Bank Entry"
	if mode_of_payment and mode_of_payment_type.get(mode_of_payment) == "Cash":
		je.voucher_type = "Cash Entry"

	paid_amt = 0
	party_account = get_party_account("Supplier", supplier, doc.company)
	for d in doc.references:
		if d.supplier == supplier and (not mode_of_payment or mode_of_payment == d.mode_of_payment):
			je.append(
				"accounts",
				{
					"account": party_account,
					"debit_in_account_currency": d.amount,
					"party_type": "Supplier",
					"party": supplier,
					"reference_type": d.reference_doctype,
					"reference_name": d.reference_name,
				},
			)

			paid_amt += d.amount

	je.append("accounts", {"account": doc.account, "credit_in_account_currency": paid_amt})

	je.flags.ignore_mandatory = True
	je.save()
	frappe.msgprint(_("{0} {1} created").format(je.doctype, je.name))
